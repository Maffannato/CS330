///////////////////////////////////////////////////////////////////////////////
// SceneManager.cpp
// ============
// manage the loading and rendering of 3D scenes
//
//  AUTHOR: Brian Battersby - SNHU Instructor / Computer Science
//	Created for CS-330-Computational Graphics and Visualization, Nov. 1st, 2023
///////////////////////////////////////////////////////////////////////////////

#include "SceneManager.h"

#ifndef STB_IMAGE_IMPLEMENTATION
#define STB_IMAGE_IMPLEMENTATION
#include "stb_image.h"
#endif

#include <glm/gtx/transform.hpp>

// declaration of global variables
namespace
{
	const char* g_ModelName = "model";
	const char* g_ColorValueName = "objectColor";
	const char* g_TextureValueName = "objectTexture";
	const char* g_UseTextureName = "bUseTexture";
	const char* g_UseLightingName = "bUseLighting";
}

/***********************************************************
 *  SceneManager()
 *
 *  The constructor for the class
 ***********************************************************/
SceneManager::SceneManager(ShaderManager *pShaderManager)
{
	m_pShaderManager = pShaderManager;
	m_basicMeshes = new ShapeMeshes();
	m_loadedTextures = 0;   // no textures loaded yet
}

/***********************************************************
 *  ~SceneManager()
 *
 *  The destructor for the class
 ***********************************************************/
SceneManager::~SceneManager()
{
	DestroyGLTextures();
	m_pShaderManager = NULL;
	delete m_basicMeshes;
	m_basicMeshes = NULL;
}

/***********************************************************
 *  CreateGLTexture()
 *
 *  This method is used for loading textures from image files,
 *  configuring the texture mapping parameters in OpenGL,
 *  generating the mipmaps, and loading the read texture into
 *  the next available texture slot in memory.
 ***********************************************************/
bool SceneManager::CreateGLTexture(const char* filename, std::string tag)
{
	int width = 0;
	int height = 0;
	int colorChannels = 0;
	GLuint textureID = 0;

	// indicate to always flip images vertically when loaded
	stbi_set_flip_vertically_on_load(true);

	// try to parse the image data from the specified image file
	unsigned char* image = stbi_load(
		filename,
		&width,
		&height,
		&colorChannels,
		0);

	// if the image was successfully read from the image file
	if (image)
	{
		std::cout << "Successfully loaded image:" << filename << ", width:" << width << ", height:" << height << ", channels:" << colorChannels << std::endl;

		glGenTextures(1, &textureID);
		glBindTexture(GL_TEXTURE_2D, textureID);

		// set the texture wrapping parameters
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
		// set texture filtering parameters
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR_MIPMAP_LINEAR);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

		// if the loaded image is in RGB format
		if (colorChannels == 3)
			glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB8, width, height, 0, GL_RGB, GL_UNSIGNED_BYTE, image);
		// if the loaded image is in RGBA format - it supports transparency
		else if (colorChannels == 4)
			glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA8, width, height, 0, GL_RGBA, GL_UNSIGNED_BYTE, image);
		else
		{
			std::cout << "Not implemented to handle image with " << colorChannels << " channels" << std::endl;
			return false;
		}

		// generate the texture mipmaps for mapping textures to lower resolutions
		glGenerateMipmap(GL_TEXTURE_2D);

		// free the image data from local memory
		stbi_image_free(image);
		glBindTexture(GL_TEXTURE_2D, 0); // Unbind the texture

		// register the loaded texture and associate it with the special tag string
		m_textureIDs[m_loadedTextures].ID = textureID;
		m_textureIDs[m_loadedTextures].tag = tag;
		m_loadedTextures++;

		return true;
	}

	std::cout << "Could not load image:" << filename << std::endl;

	// Error loading the image
	return false;
}

/***********************************************************
 *  BindGLTextures()
 *
 *  This method is used for binding the loaded textures to
 *  OpenGL texture memory slots.  There are up to 16 slots.
 ***********************************************************/
void SceneManager::BindGLTextures()
{
	for (int i = 0; i < m_loadedTextures; i++)
	{
		// bind textures on corresponding texture units
		glActiveTexture(GL_TEXTURE0 + i);
		glBindTexture(GL_TEXTURE_2D, m_textureIDs[i].ID);
	}
}

/***********************************************************
 *  DestroyGLTextures()
 *
 *  This method is used for freeing the memory in all the
 *  used texture memory slots.
 ***********************************************************/
void SceneManager::DestroyGLTextures()
{
	for (int i = 0; i < m_loadedTextures; i++)
	{
		glDeleteTextures(1, &m_textureIDs[i].ID);
	}
}

/***********************************************************
 *  FindTextureID()
 *
 *  This method is used for getting an ID for the previously
 *  loaded texture bitmap associated with the passed in tag.
 ***********************************************************/
int SceneManager::FindTextureID(std::string tag)
{
	int textureID = -1;
	int index = 0;
	bool bFound = false;

	while ((index < m_loadedTextures) && (bFound == false))
	{
		if (m_textureIDs[index].tag.compare(tag) == 0)
		{
			textureID = m_textureIDs[index].ID;
			bFound = true;
		}
		else
			index++;
	}

	return(textureID);
}

/***********************************************************
 *  FindTextureSlot()
 *
 *  This method is used for getting a slot index for the previously
 *  loaded texture bitmap associated with the passed in tag.
 ***********************************************************/
int SceneManager::FindTextureSlot(std::string tag)
{
	int textureSlot = -1;
	int index = 0;
	bool bFound = false;

	while ((index < m_loadedTextures) && (bFound == false))
	{
		if (m_textureIDs[index].tag.compare(tag) == 0)
		{
			textureSlot = index;
			bFound = true;
		}
		else
			index++;
	}

	return(textureSlot);
}

/***********************************************************
 *  FindMaterial()
 *
 *  This method is used for getting a material from the previously
 *  defined materials list that is associated with the passed in tag.
 ***********************************************************/
bool SceneManager::FindMaterial(std::string tag, OBJECT_MATERIAL& material)
{
	if (m_objectMaterials.size() == 0)
	{
		return(false);
	}

	size_t index = 0;
	bool bFound = false;
	while ((index < m_objectMaterials.size()) && (bFound == false))
	{
		if (m_objectMaterials[index].tag.compare(tag) == 0)
		{
			bFound = true;
			material.ambientColor = m_objectMaterials[index].ambientColor;
			material.ambientStrength = m_objectMaterials[index].ambientStrength;
			material.diffuseColor = m_objectMaterials[index].diffuseColor;
			material.specularColor = m_objectMaterials[index].specularColor;
			material.shininess = m_objectMaterials[index].shininess;
		}
		else
		{
			index++;
		}
	}

	return(bFound);
}

/***********************************************************
 *  SetTransformations()
 *
 *  This method is used for setting the transform buffer
 *  using the passed in transformation values.
 ***********************************************************/
void SceneManager::SetTransformations(
	glm::vec3 scaleXYZ,
	float XrotationDegrees,
	float YrotationDegrees,
	float ZrotationDegrees,
	glm::vec3 positionXYZ)
{
	// variables for this method
	glm::mat4 modelView;
	glm::mat4 scale;
	glm::mat4 rotationX;
	glm::mat4 rotationY;
	glm::mat4 rotationZ;
	glm::mat4 translation;

	// set the scale value in the transform buffer
	scale = glm::scale(scaleXYZ);
	// set the rotation values in the transform buffer
	rotationX = glm::rotate(glm::radians(XrotationDegrees), glm::vec3(1.0f, 0.0f, 0.0f));
	rotationY = glm::rotate(glm::radians(YrotationDegrees), glm::vec3(0.0f, 1.0f, 0.0f));
	rotationZ = glm::rotate(glm::radians(ZrotationDegrees), glm::vec3(0.0f, 0.0f, 1.0f));
	// set the translation value in the transform buffer
	translation = glm::translate(positionXYZ);

	modelView = translation * rotationX * rotationY * rotationZ * scale;

	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setMat4Value(g_ModelName, modelView);
	}
}

/***********************************************************
 *  SetShaderColor()
 *
 *  This method is used for setting the passed in color
 *  into the shader for the next draw command
 ***********************************************************/
void SceneManager::SetShaderColor(
	float redColorValue,
	float greenColorValue,
	float blueColorValue,
	float alphaValue)
{
	// variables for this method
	glm::vec4 currentColor;

	currentColor.r = redColorValue;
	currentColor.g = greenColorValue;
	currentColor.b = blueColorValue;
	currentColor.a = alphaValue;

	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setIntValue(g_UseTextureName, false);
		m_pShaderManager->setVec4Value(g_ColorValueName, currentColor);
	}
}

/***********************************************************
 *  SetShaderTexture()
 *
 *  This method is used for setting the texture data
 *  associated with the passed in ID into the shader.
 ***********************************************************/
void SceneManager::SetShaderTexture(
	std::string textureTag)
{
	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setIntValue(g_UseTextureName, true);

		int textureID = -1;
		textureID = FindTextureSlot(textureTag);
		m_pShaderManager->setSampler2DValue(g_TextureValueName, textureID);
	}
}

/***********************************************************
 *  SetTextureUVScale()
 *
 *  This method is used for setting the texture UV scale
 *  values into the shader.
 ***********************************************************/
void SceneManager::SetTextureUVScale(float u, float v)
{
	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setVec2Value("UVscale", glm::vec2(u, v));
	}
}

/***********************************************************
 *  SetShaderMaterial()
 *
 *  This method is used for passing the material values
 *  into the shader.
 ***********************************************************/
void SceneManager::SetShaderMaterial(
	std::string materialTag)
{
	if (m_objectMaterials.size() > 0)
	{
		OBJECT_MATERIAL material;
		bool bReturn = false;

		bReturn = FindMaterial(materialTag, material);
		if (bReturn == true)
		{
			m_pShaderManager->setVec3Value("material.ambientColor", material.ambientColor);
			m_pShaderManager->setFloatValue("material.ambientStrength", material.ambientStrength);
			m_pShaderManager->setVec3Value("material.diffuseColor", material.diffuseColor);
			m_pShaderManager->setVec3Value("material.specularColor", material.specularColor);
			m_pShaderManager->setFloatValue("material.shininess", material.shininess);
		}
	}
}
/***********************************************************
 *  SetupSceneLights()
 *
 *  Configures the light sources for the desk scene.
 *  Light 0: warm overhead key light (main illumination).
 *  Light 1: dim cool fill light (simulates monitor glow and
 *           keeps front faces from falling into shadow).
 ***********************************************************/
void SceneManager::SetupSceneLights()
{
	// Turn on lighting in the fragment shader
	m_pShaderManager->setBoolValue(g_UseLightingName, true);

	// ---- Light 0: warm overhead key light (dimmed) ----
	m_pShaderManager->setVec3Value("lightSources[0].position", 0.0f, 14.0f, 4.0f);
	m_pShaderManager->setVec3Value("lightSources[0].ambientColor", 0.20f, 0.18f, 0.16f);
	m_pShaderManager->setVec3Value("lightSources[0].diffuseColor", 0.40f, 0.37f, 0.32f);
	m_pShaderManager->setVec3Value("lightSources[0].specularColor", 0.25f, 0.25f, 0.22f);
	m_pShaderManager->setFloatValue("lightSources[0].focalStrength", 8.0f);
	m_pShaderManager->setFloatValue("lightSources[0].specularIntensity", 0.25f);

	// ---- Light 1: cool fill light from front-left ----
	m_pShaderManager->setVec3Value("lightSources[1].position", -6.0f, 6.0f, 10.0f);
	m_pShaderManager->setVec3Value("lightSources[1].ambientColor", 0.05f, 0.05f, 0.08f);
	m_pShaderManager->setVec3Value("lightSources[1].diffuseColor", 0.25f, 0.30f, 0.45f);
	m_pShaderManager->setVec3Value("lightSources[1].specularColor", 0.20f, 0.20f, 0.30f);
	m_pShaderManager->setFloatValue("lightSources[1].focalStrength", 8.0f);
	m_pShaderManager->setFloatValue("lightSources[1].specularIntensity", 0.20f);

	// ---- Light 2: strong blue light from the curved monitor ---
	m_pShaderManager->setVec3Value("lightSources[2].position", 3.3f, 8.0f, -4.5f);
	m_pShaderManager->setVec3Value("lightSources[2].ambientColor", 0.02f, 0.04f, 0.72f);
	m_pShaderManager->setVec3Value("lightSources[2].diffuseColor", 0.15f, 0.35f, 0.95f);
	m_pShaderManager->setVec3Value("lightSources[2].specularColor", 0.20f, 0.40f, 0.90f);
	m_pShaderManager->setFloatValue("lightSources[2].focalStrength", 32.0f);
	m_pShaderManager->setFloatValue("lightSources[2].specularIntensity", 0.40f);

	// ---- Light 3: strong blue light from the curved monitor ---
	m_pShaderManager->setVec3Value("lightSources[3].position", 3.0f, 4.0f, -5.5f);
	m_pShaderManager->setVec3Value("lightSources[3].ambientColor", 0.02f, 0.04f, 0.72f);
	m_pShaderManager->setVec3Value("lightSources[3].diffuseColor", 0.15f, 0.35f, 0.95f);
	m_pShaderManager->setVec3Value("lightSources[3].specularColor", 0.20f, 0.40f, 0.90f);
	m_pShaderManager->setFloatValue("lightSources[3].focalStrength", 32.0f);
	m_pShaderManager->setFloatValue("lightSources[3].specularIntensity", 0.10f);
}
/***********************************************************
 *  DefineObjectMaterials()
 *
 *  Defines the surface materials used by the scene objects.
 *  Each material controls how strongly an object reflects
 *  ambient, diffuse, and specular light.
 ***********************************************************/
void SceneManager::DefineObjectMaterials()
{
	// Desk mat plane: smooth surface that shows a visible light reflection
	OBJECT_MATERIAL deskMatMaterial;
	deskMatMaterial.ambientColor = glm::vec3(0.3f, 0.3f, 0.3f);
	deskMatMaterial.ambientStrength = 0.3f;
	deskMatMaterial.diffuseColor = glm::vec3(0.7f, 0.7f, 0.7f);
	deskMatMaterial.specularColor = glm::vec3(0.5f, 0.5f, 0.5f);
	deskMatMaterial.shininess = 2.0f;
	deskMatMaterial.tag = "deskMat";
	m_objectMaterials.push_back(deskMatMaterial);

	// Plastic deck body and keys: low gloss
	OBJECT_MATERIAL plasticMaterial;
	plasticMaterial.ambientColor = glm::vec3(0.35f, 0.35f, 0.35f);
	plasticMaterial.ambientStrength = 0.45f;
	plasticMaterial.diffuseColor = glm::vec3(0.7f, 0.7f, 0.7f);
	plasticMaterial.specularColor = glm::vec3(0.15f, 0.15f, 0.15f);
	plasticMaterial.shininess = 6.0f;
	plasticMaterial.tag = "plasticMat";
	m_objectMaterials.push_back(plasticMaterial);

	// Brushed metal buttons and rods: moderate gloss
	OBJECT_MATERIAL metalMaterial;
	metalMaterial.ambientColor = glm::vec3(0.3f, 0.3f, 0.3f);
	metalMaterial.ambientStrength = 0.3f;
	metalMaterial.diffuseColor = glm::vec3(0.2f, 0.2f, 0.2f);
	metalMaterial.specularColor = glm::vec3(0.4f, 0.4f, 0.4f);
	metalMaterial.shininess = 16.0f;
	metalMaterial.tag = "metalMat";
	m_objectMaterials.push_back(metalMaterial);

	// Glass key faces: glossy surface with a tight, bright highlight
	OBJECT_MATERIAL glassMaterial;
	glassMaterial.ambientColor = glm::vec3(0.15f, 0.15f, 0.15f);
	glassMaterial.ambientStrength = 0.2f;
	glassMaterial.diffuseColor = glm::vec3(0.35f, 0.35f, 0.35f);
	glassMaterial.specularColor = glm::vec3(0.5f, 0.5f, 0.5f);
	glassMaterial.shininess = 96.0f;
	glassMaterial.tag = "glassMat";
	m_objectMaterials.push_back(glassMaterial);

	// Tumbler body: coated steel with a soft sheen
	OBJECT_MATERIAL tumblerMaterial;
	tumblerMaterial.ambientColor = glm::vec3(0.3f, 0.3f, 0.3f);
	tumblerMaterial.ambientStrength = 0.3f;
	tumblerMaterial.diffuseColor = glm::vec3(0.3f, 0.3f, 0.3f);
	tumblerMaterial.specularColor = glm::vec3(0.2f, 0.2f, 0.2f);
	tumblerMaterial.shininess = 16.0f;
	tumblerMaterial.tag = "tumblerMat";
	m_objectMaterials.push_back(tumblerMaterial);

	// Silicone: soft, rubbery surface with a wide, faint sheen
	OBJECT_MATERIAL siliconeMaterial;
	siliconeMaterial.ambientColor = glm::vec3(0.3f, 0.3f, 0.3f);
	siliconeMaterial.ambientStrength = 0.35f;
	siliconeMaterial.diffuseColor = glm::vec3(0.45f, 0.45f, 0.45f);
	siliconeMaterial.specularColor = glm::vec3(0.2f, 0.2f, 0.2f);
	siliconeMaterial.shininess = 4.0f;
	siliconeMaterial.tag = "siliconeMat";
	m_objectMaterials.push_back(siliconeMaterial);

	// Monitor screen: bright panel with a slight sheen
	OBJECT_MATERIAL screenMaterial;
	screenMaterial.ambientColor = glm::vec3(0.5f, 0.5f, 0.5f);
	screenMaterial.ambientStrength = 0.5f;
	screenMaterial.diffuseColor = glm::vec3(0.15f, 0.15f, 0.15f);
	screenMaterial.specularColor = glm::vec3(0.03f, 0.03f, 0.03f);
	screenMaterial.shininess = 8.0f;
	screenMaterial.tag = "screenMat";
	m_objectMaterials.push_back(screenMaterial);
}

/**************************************************************/
/*** STUDENTS CAN MODIFY the code in the methods BELOW for  ***/
/*** preparing and rendering their own 3D replicated scenes.***/
/*** Please refer to the code in the OpenGL sample project  ***/
/*** for assistance.                                        ***/
/**************************************************************/


/***********************************************************
 *  PrepareScene()
 *
 *  This method is used for preparing the 3D scene by loading
 *  the shapes, textures in memory to support the 3D scene 
 *  rendering
 ***********************************************************/
void SceneManager::PrepareScene()
{

	LoadSceneTextures();
	DefineObjectMaterials();
	SetupSceneLights();
	// only one instance of a particular mesh needs to be
	// loaded in memory no matter how many times it is drawn
	// in the rendered 3D scene

	m_basicMeshes->LoadPlaneMesh();
	m_basicMeshes->LoadBoxMesh();
	m_basicMeshes->LoadCylinderMesh();
	m_basicMeshes->LoadTaperedCylinderMesh();
	m_basicMeshes->LoadTorusMesh();
	m_basicMeshes->LoadPrismMesh();
	m_basicMeshes->LoadSphereMesh();
	
}

/***********************************************************
 *  RenderScene()
 *
 *  This method is used for rendering the 3D scene by 
 *  transforming and drawing the basic 3D shapes
 ***********************************************************/
void SceneManager::RenderScene()
{
	RenderDeskMat();//Draws the Desk mat

	// back of the desk
	//RenderCurvedMonitor(glm::vec3(3.0f, 0.0f, -8.0f), 0.5f);
	//RenderSecondaryMonitor(glm::vec3(-17.0f, 0.0f, -9.5f), 0.5f);	// set back so the curved monitor overlaps it
	//RenderLegoTurtle(glm::vec3(2.5f, 0.0f, -6.3f), 0.5f);
	
	RenderTumbler(glm::vec3(-12.0f, 0.0f, 3.0f), 1.3f);
	RenderStreamDeck(glm::vec3(-7.5f, 1.5f, -3.0f), 0.5f);
	RenderKeyboard(glm::vec3(3.0f, 0.0f, 0.0f), 0.5f);
	RenderCoiledCable(glm::vec3(0.0f, 0.0f, -2.615f), 0.8f);
	RenderFingerprintReader(glm::vec3(12.5f, 0.0f, -2.5f), 0.5f);
	RenderCurvedMonitor(glm::vec3(3.0f, 0.0f, -8.0f), 0.5f);
	RenderSecondaryMonitor(glm::vec3(-14.5f, 0.0f, -3.6f), 0.5f);	
}

///////////////////////////////////////////////////////////////////////////////
// SceneManager.h
// ============
// manage the loading and rendering of 3D scenes
//
//  AUTHOR: Brian Battersby - SNHU Instructor / Computer Science
//	Created for CS-330-Computational Graphics and Visualization, Nov. 1st, 2023
///////////////////////////////////////////////////////////////////////////////

#pragma once

#include "ShaderManager.h"
#include "ShapeMeshes.h"

#include <string>
#include <vector>

/***********************************************************
 *  SceneManager
 *
 *  This class contains the code for preparing and rendering
 *  3D scenes, including the shader settings.
 ***********************************************************/
class SceneManager
{
public:
	// constructor
	SceneManager(ShaderManager *pShaderManager);
	// destructor
	~SceneManager();

	struct TEXTURE_INFO
	{
		std::string tag;
		uint32_t ID;
	};

	struct OBJECT_MATERIAL
	{
		float ambientStrength;
		glm::vec3 ambientColor;
		glm::vec3 diffuseColor;
		glm::vec3 specularColor;
		float shininess;
		std::string tag;
	};

private:
	// pointer to shader manager object
	ShaderManager* m_pShaderManager;
	// pointer to basic shapes object
	ShapeMeshes* m_basicMeshes;
	// total number of loaded textures
	int m_loadedTextures;
	// loaded textures info
	TEXTURE_INFO m_textureIDs[16];
	// defined object materials
	std::vector<OBJECT_MATERIAL> m_objectMaterials;

	// load texture images and convert to OpenGL texture data
	bool CreateGLTexture(const char* filename, std::string tag);
	// bind loaded OpenGL textures to slots in memory
	void BindGLTextures();
	// free the loaded OpenGL textures
	void DestroyGLTextures();
	// find a loaded texture by tag
	int FindTextureID(std::string tag);
	int FindTextureSlot(std::string tag);
	// find a defined material by tag
	bool FindMaterial(std::string tag, OBJECT_MATERIAL& material);

	// set the transformation values 
	// into the transform buffer
	void SetTransformations(
		glm::vec3 scaleXYZ,
		float XrotationDegrees,
		float YrotationDegrees,
		float ZrotationDegrees,
		glm::vec3 positionXYZ);

	// set the color values into the shader
	void SetShaderColor(
		float redColorValue,
		float greenColorValue,
		float blueColorValue,
		float alphaValue);

	// set the texture data into the shader
	void SetShaderTexture(
		std::string textureTag);

	// set the UV scale for the texture mapping
	void SetTextureUVScale(
		float u, float v);

	// set the object material into the shader
	void SetShaderMaterial(
		std::string materialTag);

	// define reusable surface materials for the scene
	void DefineObjectMaterials();
	
	// configure the scene's light sources in the shader
	void SetupSceneLights();

	void LoadSceneTextures()
	{
		CreateGLTexture("../../Utilities/textures/plastic.png", "plastic");	// body, base, feet
		CreateGLTexture("../../Utilities/textures/Glass.png", "pads");			// button faces
		CreateGLTexture("../../Utilities/textures/DarkStainless.jpg", "metal");		// cylinders, support rods
		CreateGLTexture("../../Utilities/textures/DeskMat.jpg", "desktop");			// desk mat (tiled)
		CreateGLTexture("../../Utilities/textures/stainlessGreen.jpg", "greenmetal"); //Tumbler
		CreateGLTexture("../../Utilities/textures/RattanWeave.png", "blueFabric");  //Blue Fabric
		CreateGLTexture("../../Utilities/textures/TealPlastic.png", "Teal");  //Teal Fabric
		CreateGLTexture("../../Utilities/textures/LGPlastic.png", "Grey");  //Grey Plastic

		// bind all loaded textures to their OpenGL texture slots
		BindGLTextures();
	}
	void RenderDeskMat()
	{
		SetTransformations(
			glm::vec3(20.0f, 1.0f, 10.0f),	// scale
			0.0f, 0.0f, 0.0f,				// rotation
			glm::vec3(0.0f, 0.0f, 0.0f));	// position

		SetShaderTexture("desktop");
		SetTextureUVScale(8.0f, 4.0f);		// repeat 8x across, 4x deep
		SetShaderMaterial("deskMat");
		m_basicMeshes->DrawPlaneMesh();
	}

	void DrawTexturedPart(
		glm::vec3 scaleXYZ,
		float XrotationDegrees,
		float YrotationDegrees,
		float ZrotationDegrees,
		glm::vec3 positionXYZ,
		const std::string& textureTag,
		const std::string& materialTag,
		glm::vec2 uvScale,
		bool bCylinder)
	{
		SetTransformations(scaleXYZ, XrotationDegrees, 0.0f, ZrotationDegrees, positionXYZ);
		SetShaderTexture(textureTag);
		SetTextureUVScale(uvScale.x, uvScale.y);
		SetShaderMaterial(materialTag);

		if (bCylinder)
			m_basicMeshes->DrawCylinderMesh();
		else
			m_basicMeshes->DrawBoxMesh();
	}

	//Keeps the object called as a group with position and scale linked. Rotation is trickier.
	void RenderStreamDeck(glm::vec3 basePosition, float baseScale)
	{
		const glm::vec2 noTile(1.0f, 1.0f);

		// converts an offset in the deck's local space to a world position
		auto at = [&](float x, float y, float z)
			{
				return basePosition + baseScale * glm::vec3(x, y, z);
			};

		// --- body, base, and feet: black plastic ---
		DrawTexturedPart(baseScale * glm::vec3(9.0f, 7.0f, 1.0f), -45.0f, 0.0f, 0.0f, basePosition, "plastic", "plasticMat", glm::vec2(3.0f, 2.0f), false);
		DrawTexturedPart(baseScale * glm::vec3(9.0f, 4.0f, 0.3f), 90.0f, 0.0f, 0.0f, at(0.0f, -2.7f, 0.0f), "plastic", "plasticMat", glm::vec2(3.0f, 1.0f), false);
		DrawTexturedPart(baseScale * glm::vec3(1.0f, 4.0f, 0.3f), 90.0f, 0.0f, 0.0f, at(-4.0f, -2.7f, -4.0f), "plastic", "plasticMat", noTile, false);	// left foot
		DrawTexturedPart(baseScale * glm::vec3(1.0f, 4.0f, 0.3f), 90.0f, 0.0f, 0.0f, at(4.0f, -2.7f, -4.0f), "plastic", "plasticMat", noTile, false);	// right foot

		// --- 5 x 3 key grid: each row steps up and back along the tilted face ---
		for (int row = 0; row < 3; row++)			// row 0 = bottom, row 2 = top
		{
			for (int col = 0; col < 5; col++)		// col 0 = left
			{
				float x = -3.2f + col * 1.6f;
				float y = -0.3f + row * 1.1f;
				float z = 1.1f - row * 1.1f;
				DrawTexturedPart(baseScale * glm::vec3(1.2f, 1.2f, 0.2f), -45.0f, 0.0f, 0.0f, at(x, y, z), "pads", "glassMat", noTile, false);
			}
		}

		// --- three front button cylinders: metal ---
		for (int i = 0; i < 3; i++)
		{
			DrawTexturedPart(baseScale * glm::vec3(0.25f, 0.15f, 0.25f), 45.0f, 0.0f, 0.0f, at(-1.6f + i * 1.6f, -1.4f, 2.2f), "metal", "metalMat", noTile, true);
		}

		// --- support rods: metal ---
		DrawTexturedPart(baseScale * glm::vec3(0.15f, 4.5f, 0.15f), 0.0f, 0.0f, 0.0f, at(3.7f, -2.7f, -2.0f), "metal", "metalMat", noTile, true);	// right
		DrawTexturedPart(baseScale * glm::vec3(0.15f, 4.5f, 0.15f), 0.0f, 0.0f, 0.0f, at(-3.7f, -2.7f, -2.0f), "metal", "metalMat", noTile, true);	// left
		DrawTexturedPart(baseScale * glm::vec3(0.15f, 7.4f, 0.15f), 0.0f, 0.0f, 90.0f, at(3.7f, -2.45f, -2.0f), "metal", "metalMat", noTile, true);	// bottom

		// cable running back toward -z
		DrawTexturedPart(baseScale * glm::vec3(0.1f, 25.0f, 0.1f), 90.0f, 90.0f, 0.0f, at(4.2f, -2.45f, -23.0f), "plastic", "plasticMat", noTile, true);
		
	}
	
	void RenderTumbler(glm::vec3 basePosition, float baseScale)
	{
		// converts an offset in the tumbler's local space to a world position
		auto at = [&](float x, float y, float z)
			{
				return basePosition + baseScale * glm::vec3(x, y, z);
			};

		// --- base ---
		SetTransformations(baseScale * glm::vec3(1.0f, 2.0f, 1.0f), 0.0f, 0.0f, 0.0f, at(0.0f, 0.0f, 0.0f));
		SetShaderTexture("greenmetal");
		SetTextureUVScale(1.0f, 1.0f);
		SetShaderMaterial("tumblerMat");
		m_basicMeshes->DrawCylinderMesh();

		// --- taper: flipped so it is narrow at the bottom ---		
		SetTransformations(baseScale * glm::vec3(1.3f, 1.3f, 1.3f), 180.0f, 0.0f, 0.0f, at(0.0f, 2.6f, 0.0f));
		SetShaderTexture("greenmetal");
		SetShaderMaterial("tumblerMat");
		m_basicMeshes->DrawTaperedCylinderMesh();

		// --- overlaps the top of the taper ---
		SetTransformations(baseScale * glm::vec3(1.3f, 4.0f, 1.3f), 0.0f, 0.0f, 0.0f, at(0.0f, 2.5f, 0.0f));
		SetShaderTexture("greenmetal");
		SetShaderMaterial("tumblerMat");
		m_basicMeshes->DrawCylinderMesh();

		// --- lid ---
		SetTransformations(baseScale * glm::vec3(1.4f, 0.3f, 1.4f), 0.0f, 0.0f, 0.0f, at(0.0f, 6.5f, 0.0f));
		SetShaderTexture("plastic");
		SetShaderMaterial("plasticMat");
		m_basicMeshes->DrawCylinderMesh();

		// --- handle ---
		SetTransformations(baseScale * glm::vec3(0.8f, 1.5f, 0.8f), 0.0f, 0.0f, 0.0f, at(1.65f, 4.5f, 0.0f));
		SetShaderTexture("greenmetal");
		SetShaderMaterial("tumblerMat");
		m_basicMeshes->DrawTorusMesh();
	}
	
	void RenderFingerprintReader(glm::vec3 basePosition, float baseScale)
	{
		// --- black plastic: base, stepped top, and cable ---
		SetShaderTexture("plastic");
		SetTextureUVScale(1.0f, 1.0f);
		SetShaderMaterial("plasticMat");

		// base
		SetTransformations(baseScale * glm::vec3(0.5f, 2.6f, 2.0f), 0.0f, 0.0f, 90.0f,
			basePosition + baseScale * glm::vec3(0.0f, 0.25f, 0.0f));
		m_basicMeshes->DrawBoxMesh();

		SetTransformations(baseScale * glm::vec3(0.5f, 2.6f, 2.0f), 6.0f, 0.0f, 90.0f,
			basePosition + baseScale * glm::vec3(0.0f, 0.6f, 0.025f));
		m_basicMeshes->DrawPrismMesh();

		// stepped top edge
		SetTransformations(baseScale * glm::vec3(1.8f, 0.3f, 1.8f), 13.0f, 0.0f, 0.0f,
			basePosition + baseScale * glm::vec3(0.0f, 0.61f, 0.0f));
		m_basicMeshes->DrawBoxMesh();

		// cable running back toward -z
		SetTransformations(baseScale * glm::vec3(0.1f, 20.0f, 0.1f), -90.0f, 0.0f, 0.0f,
			basePosition + baseScale * glm::vec3(0.0f, 0.15f, -0.9f));
		m_basicMeshes->DrawCylinderMesh();

		// --- metal bezel ring around the sensor ---
		SetShaderTexture("metal");
		SetShaderMaterial("metalMat");
		SetTransformations(baseScale * glm::vec3(1.25f, 0.03f, 1.25f), 13.0f, 0.0f, 0.0f,
			basePosition + baseScale * glm::vec3(0.0f, 0.785f, 0.0f));
		m_basicMeshes->DrawBoxMesh();

		// --- dark glass sensor ---
		SetShaderColor(0.08f, 0.09f, 0.11f, 1.0f);
		SetShaderMaterial("glassMat");
		SetTransformations(baseScale * glm::vec3(1.1f, 0.04f, 1.1f), 13.0f, 0.0f, 0.0f,
			basePosition + baseScale * glm::vec3(0.0f, 0.79f, 0.0f));
		m_basicMeshes->DrawBoxMesh();
	}

	void RenderCoiledCable(glm::vec3 basePosition, float baseScale)
	{
		//Usb-c connector		
		SetShaderColor(0.12f, 0.16f, 0.35f, 1.0f);
		SetShaderMaterial("plasticMat");

		SetTransformations(baseScale * glm::vec3(0.5f, 0.3f, 0.5f), 0.0f, 0.0f, 0.0f,
			basePosition + baseScale * glm::vec3(-0.05f, 0.34f, -0.25f));
		m_basicMeshes->DrawBoxMesh();

		//Cable
		SetShaderTexture("blueFabric");
		SetTextureUVScale(1.0f, 1.0f);
		SetShaderMaterial("siliconeMat");

		// cord out of the keyboard (rotated -90 about X so it runs back toward -z)
		SetTransformations(baseScale * glm::vec3(0.12f, 1.3f, 0.12f), -90.0f, 0.0f, 0.0f,
			basePosition + baseScale * glm::vec3(-0.05f, 0.34f, -0.3f));
		m_basicMeshes->DrawCylinderMesh();

		// coil: 30 rings, 0.2 apart, rotated to look like coil
		for (int ring = 0; ring < 30; ring++)
		{
			SetTransformations(baseScale * glm::vec3(0.45f, 0.45f, 0.45f), 0.0f, 82.0f, 0.0f,
				basePosition + baseScale * glm::vec3(ring * 0.2f, 0.54f, -2.0f));
			m_basicMeshes->DrawTorusMesh();
		}

		// straight cable after the connector (rotated -90 about Z so it runs toward +x)
		SetTransformations(baseScale * glm::vec3(0.12f, 3.5f, 0.12f), 0.0f, 0.0f, -90.0f,
			basePosition + baseScale * glm::vec3(6.2f, 0.54f, -2.0f));
		m_basicMeshes->DrawCylinderMesh();

		// rounded corner where the cable turns back
		SetTransformations(baseScale * glm::vec3(0.12f, 0.12f, 0.12f), 0.0f, 0.0f, 0.0f,
			basePosition + baseScale * glm::vec3(9.7f, 0.54f, -2.0f));
		m_basicMeshes->DrawSphereMesh();

		// cable running back toward the monitor
		SetTransformations(baseScale * glm::vec3(0.12f, 15.0f, 0.12f), -90.0f, 0.0f, 0.0f,
			basePosition + baseScale * glm::vec3(9.7f, 0.54f, -2.0f));
		m_basicMeshes->DrawCylinderMesh();

		// --- metal connector between the coil and the straight cable ---
		SetShaderTexture("metal");
		SetTextureUVScale(1.0f, 1.0f);
		SetShaderMaterial("metalMat");

		SetTransformations(baseScale * glm::vec3(0.32f, 0.35f, 0.32f), 0.0f, 0.0f, -90.0f,
			basePosition + baseScale * glm::vec3(5.9f, 0.54f, -2.0f));
		m_basicMeshes->DrawCylinderMesh();

	}

	void RenderKeyboard(glm::vec3 basePosition, float baseScale)
	{
		// --- case: black aluminum ---
		SetShaderTexture("plastic");
		SetTextureUVScale(4.0f, 1.5f);
		SetShaderMaterial("metalMat");

		// main case (extra width on the right for the numpad)
		SetTransformations(baseScale * glm::vec3(31.07f, 1.6f, 10.46f), 0.0f, 0.0f, 0.0f,
			basePosition + baseScale * glm::vec3(0.635f, 0.8f, 0.0f));
		m_basicMeshes->DrawBoxMesh();

		// V-shaped front edge, left side (lines up with the Alice split)
		SetTransformations(baseScale * glm::vec3(5.108f, 1.595f, 1.27f), 0.0f, -6.0f, 0.0f,
			basePosition + baseScale * glm::vec3(-4.928f, 0.798f, 4.863f));
		m_basicMeshes->DrawBoxMesh();

		// V-shaped front edge, right side (lines up with the Alice split)
		SetTransformations(baseScale * glm::vec3(5.108f, 1.595f, 1.27f), 0.0f, 6.0f, 0.0f,
			basePosition + baseScale * glm::vec3(0.02f, 0.798f, 4.863f));
		m_basicMeshes->DrawBoxMesh();

		// --- knob: metal cylinder in the top-left corner ---
		SetShaderTexture("metal");
		SetTextureUVScale(1.0f, 1.0f);
		SetShaderMaterial("metalMat");

		SetTransformations(baseScale * glm::vec3(0.57f, 0.83f, 0.57f), 0.0f, 0.0f, 0.0f,
			basePosition + baseScale * glm::vec3(-13.376f, 1.54f, -3.516f));
		m_basicMeshes->DrawCylinderMesh();


		// --- teal keys: Esc and Enter ---
		SetShaderTexture("Teal");
		SetTextureUVScale(1.0f, 1.0f);
		SetShaderMaterial("plasticMat");

		// Esc
		SetTransformations(baseScale * glm::vec3(1.13f, 0.7f, 1.13f), 0.0f, -6.0f, 0.0f,
			basePosition + baseScale * glm::vec3(-11.889f, 1.89f, -3.537f));
		m_basicMeshes->DrawBoxMesh();

		// Enter
		SetTransformations(baseScale * glm::vec3(2.639f, 0.7f, 1.13f), 0.0f, 6.0f, 0.0f,
			basePosition + baseScale * glm::vec3(6.679f, 1.89f, 0.63f));
		m_basicMeshes->DrawBoxMesh();

		// --- gray keys ---
		SetShaderTexture("Grey");
		SetTextureUVScale(1.0f, 1.0f);
		SetShaderMaterial("plasticMat");

		// F5
		SetTransformations(baseScale * glm::vec3(1.13f, 0.7f, 1.13f), 0.0f, -6.0f, 0.0f,
			basePosition + baseScale * glm::vec3(-4.627f, 1.89f, -2.774f));
		m_basicMeshes->DrawBoxMesh();

		// F6
		SetTransformations(baseScale * glm::vec3(1.13f, 0.7f, 1.13f), 0.0f, -6.0f, 0.0f,
			basePosition + baseScale * glm::vec3(-3.364f, 1.89f, -2.641f));
		m_basicMeshes->DrawBoxMesh();

		// left Space
		SetTransformations(baseScale * glm::vec3(2.639f, 0.7f, 1.13f), 0.0f, -6.0f, 0.0f,
			basePosition + baseScale * glm::vec3(-5.405f, 1.89f, 3.721f));
		m_basicMeshes->DrawBoxMesh();

		// F7
		SetTransformations(baseScale * glm::vec3(1.13f, 0.7f, 1.13f), 0.0f, 6.0f, 0.0f,
			basePosition + baseScale * glm::vec3(-1.16f, 1.89f, -2.568f));
		m_basicMeshes->DrawBoxMesh();

		// F8
		SetTransformations(baseScale * glm::vec3(1.13f, 0.7f, 1.13f), 0.0f, 6.0f, 0.0f,
			basePosition + baseScale * glm::vec3(0.103f, 1.89f, -2.701f));
		m_basicMeshes->DrawBoxMesh();

		// right Space
		SetTransformations(baseScale * glm::vec3(3.242f, 0.7f, 1.13f), 0.0f, 6.0f, 0.0f,
			basePosition + baseScale * glm::vec3(-0.508f, 1.89f, 3.94f));
		m_basicMeshes->DrawBoxMesh();

		// `
		SetTransformations(baseScale * glm::vec3(1.13f, 0.7f, 1.13f), 0.0f, -6.0f, 0.0f,
			basePosition + baseScale * glm::vec3(-11.031f, 1.89f, -1.979f));
		m_basicMeshes->DrawBoxMesh();

		// Tab
		SetTransformations(baseScale * glm::vec3(1.734f, 0.7f, 1.13f), 0.0f, -6.0f, 0.0f,
			basePosition + baseScale * glm::vec3(-10.848f, 1.89f, -0.682f));
		m_basicMeshes->DrawBoxMesh();

		// Caps Lock
		SetTransformations(baseScale * glm::vec3(2.035f, 0.7f, 1.13f), 0.0f, -6.0f, 0.0f,
			basePosition + baseScale * glm::vec3(-10.823f, 1.89f, 0.597f));
		m_basicMeshes->DrawBoxMesh();

		// left Shift
		SetTransformations(baseScale * glm::vec3(2.639f, 0.7f, 1.13f), 0.0f, -6.0f, 0.0f,
			basePosition + baseScale * glm::vec3(-10.64f, 1.89f, 1.893f));
		m_basicMeshes->DrawBoxMesh();

		// left Ctrl
		SetTransformations(baseScale * glm::vec3(1.432f, 0.7f, 1.13f), 0.0f, -6.0f, 0.0f,
			basePosition + baseScale * glm::vec3(-11.404f, 1.89f, 3.09f));
		m_basicMeshes->DrawBoxMesh();

		// Option
		SetTransformations(baseScale * glm::vec3(1.432f, 0.7f, 1.13f), 0.0f, -6.0f, 0.0f,
			basePosition + baseScale * glm::vec3(-9.826f, 1.89f, 3.256f));
		m_basicMeshes->DrawBoxMesh();

		// left Alt
		SetTransformations(baseScale * glm::vec3(1.432f, 0.7f, 1.13f), 0.0f, -6.0f, 0.0f,
			basePosition + baseScale * glm::vec3(-7.615f, 1.89f, 3.488f));
		m_basicMeshes->DrawBoxMesh();

		// Fn
		SetTransformations(baseScale * glm::vec3(1.13f, 0.7f, 1.13f), 0.0f, -6.0f, 0.0f,
			basePosition + baseScale * glm::vec3(-3.353f, 1.89f, 3.936f));
		m_basicMeshes->DrawBoxMesh();

		// Backspace
		SetTransformations(baseScale * glm::vec3(2.337f, 0.7f, 1.13f), 0.0f, 6.0f, 0.0f,
			basePosition + baseScale * glm::vec3(6.571f, 1.89f, -1.912f));
		m_basicMeshes->DrawBoxMesh();

		// Backslash
		SetTransformations(baseScale* glm::vec3(1.734f, 0.7f, 1.13f), 0.0f, 6.0f, 0.0f,
			basePosition + baseScale * glm::vec3(7.02f, 1.89f, -0.682f));
		m_basicMeshes->DrawBoxMesh();

		// right Shift
		SetTransformations(baseScale * glm::vec3(2.035f, 0.7f, 1.13f), 0.0f, 6.0f, 0.0f,
			basePosition + baseScale * glm::vec3(6.306f, 1.89f, 1.946f));
		m_basicMeshes->DrawBoxMesh();

		// right Alt
		SetTransformations(baseScale * glm::vec3(1.432f, 0.7f, 1.13f), 0.0f, 6.0f, 0.0f,
			basePosition + baseScale * glm::vec3(2.019f, 1.89f, 3.674f));
		m_basicMeshes->DrawBoxMesh();

		// right Ctrl
		SetTransformations(baseScale * glm::vec3(1.432f, 0.7f, 1.13f), 0.0f, 6.0f, 0.0f,
			basePosition + baseScale * glm::vec3(3.597f, 1.89f, 3.508f));
		m_basicMeshes->DrawBoxMesh();

		// M1
		SetTransformations(baseScale * glm::vec3(1.13f, 0.7f, 1.13f), 0.0f, 0.0f, 0.0f,
			basePosition + baseScale * glm::vec3(-13.122f, 1.89f, -2.055f));
		m_basicMeshes->DrawBoxMesh();

		// M2
		SetTransformations(baseScale * glm::vec3(1.13f, 0.7f, 1.13f), 0.0f, 0.0f, 0.0f,
			basePosition + baseScale * glm::vec3(-13.122f, 1.89f, -0.785f));
		m_basicMeshes->DrawBoxMesh();

		// M3
		SetTransformations(baseScale * glm::vec3(1.13f, 0.7f, 1.13f), 0.0f, 0.0f, 0.0f,
			basePosition + baseScale * glm::vec3(-13.122f, 1.89f, 0.485f));
		m_basicMeshes->DrawBoxMesh();

		// M4
		SetTransformations(baseScale * glm::vec3(1.13f, 0.7f, 1.13f), 0.0f, 0.0f, 0.0f,
			basePosition + baseScale * glm::vec3(-13.122f, 1.89f, 1.755f));
		m_basicMeshes->DrawBoxMesh();

		// M5
		SetTransformations(baseScale * glm::vec3(1.13f, 0.7f, 1.13f), 0.0f, 0.0f, 0.0f,
			basePosition + baseScale * glm::vec3(-13.122f, 1.89f, 3.025f));
		m_basicMeshes->DrawBoxMesh();

		// Del
		SetTransformations(baseScale * glm::vec3(1.13f, 0.7f, 1.13f), 0.0f, 0.0f, 0.0f,
			basePosition + baseScale * glm::vec3(7.389f, 1.89f, -3.516f));
		m_basicMeshes->DrawBoxMesh();

		

		// --- dark keys ---
		SetShaderTexture("plastic");
		SetTextureUVScale(1.0f, 1.0f);
		SetShaderMaterial("plasticMat");

		// F1
		SetTransformations(baseScale* glm::vec3(1.13f, 0.7f, 1.13f), 0.0f, -6.0f, 0.0f,
			basePosition + baseScale * glm::vec3(-10.31f, 1.89f, -3.371f));
		m_basicMeshes->DrawBoxMesh();

		// F2
		SetTransformations(baseScale* glm::vec3(1.13f, 0.7f, 1.13f), 0.0f, -6.0f, 0.0f,
			basePosition + baseScale * glm::vec3(-9.047f, 1.89f, -3.239f));
		m_basicMeshes->DrawBoxMesh();

		// F3
		SetTransformations(baseScale* glm::vec3(1.13f, 0.7f, 1.13f), 0.0f, -6.0f, 0.0f,
			basePosition + baseScale * glm::vec3(-7.468f, 1.89f, -3.073f));
		m_basicMeshes->DrawBoxMesh();

		// F4
		SetTransformations(baseScale* glm::vec3(1.13f, 0.7f, 1.13f), 0.0f, -6.0f, 0.0f,
			basePosition + baseScale * glm::vec3(-6.205f, 1.89f, -2.94f));
		m_basicMeshes->DrawBoxMesh();

		// F9
		SetTransformations(baseScale* glm::vec3(1.13f, 0.7f, 1.13f), 0.0f, 6.0f, 0.0f,
			basePosition + baseScale * glm::vec3(1.682f, 1.89f, -2.867f));
		m_basicMeshes->DrawBoxMesh();

		// F10
		SetTransformations(baseScale* glm::vec3(1.13f, 0.7f, 1.13f), 0.0f, 6.0f, 0.0f,
			basePosition + baseScale * glm::vec3(2.945f, 1.89f, -3.0f));
		m_basicMeshes->DrawBoxMesh();

		// F11
		SetTransformations(baseScale* glm::vec3(1.13f, 0.7f, 1.13f), 0.0f, 6.0f, 0.0f,
			basePosition + baseScale * glm::vec3(4.524f, 1.89f, -3.166f));
		m_basicMeshes->DrawBoxMesh();

		// F12
		SetTransformations(baseScale* glm::vec3(1.13f, 0.7f, 1.13f), 0.0f, 6.0f, 0.0f,
			basePosition + baseScale * glm::vec3(5.787f, 1.89f, -3.298f));
		m_basicMeshes->DrawBoxMesh();

		// 1
		SetTransformations(baseScale * glm::vec3(1.13f, 0.7f, 1.13f), 0.0f, -6.0f, 0.0f,
			basePosition + baseScale * glm::vec3(-9.768f, 1.89f, -1.846f));
		m_basicMeshes->DrawBoxMesh();

		// 2
		SetTransformations(baseScale * glm::vec3(1.13f, 0.7f, 1.13f), 0.0f, -6.0f, 0.0f,
			basePosition + baseScale * glm::vec3(-8.505f, 1.89f, -1.713f));
		m_basicMeshes->DrawBoxMesh();

		// 3
		SetTransformations(baseScale * glm::vec3(1.13f, 0.7f, 1.13f), 0.0f, -6.0f, 0.0f,
			basePosition + baseScale * glm::vec3(-7.242f, 1.89f, -1.58f));
		m_basicMeshes->DrawBoxMesh();

		// 4
		SetTransformations(baseScale * glm::vec3(1.13f, 0.7f, 1.13f), 0.0f, -6.0f, 0.0f,
			basePosition + baseScale * glm::vec3(-5.979f, 1.89f, -1.448f));
		m_basicMeshes->DrawBoxMesh();

		// 5
		SetTransformations(baseScale * glm::vec3(1.13f, 0.7f, 1.13f), 0.0f, -6.0f, 0.0f,
			basePosition + baseScale * glm::vec3(-4.716f, 1.89f, -1.315f));
		m_basicMeshes->DrawBoxMesh();

		// 6
		SetTransformations(baseScale * glm::vec3(1.13f, 0.7f, 1.13f), 0.0f, -6.0f, 0.0f,
			basePosition + baseScale * glm::vec3(-3.453f, 1.89f, -1.182f));
		m_basicMeshes->DrawBoxMesh();

		// Q
		SetTransformations(baseScale * glm::vec3(1.13f, 0.7f, 1.13f), 0.0f, -6.0f, 0.0f,
			basePosition + baseScale * glm::vec3(-9.269f, 1.89f, -0.517f));
		m_basicMeshes->DrawBoxMesh();

		// W
		SetTransformations(baseScale * glm::vec3(1.13f, 0.7f, 1.13f), 0.0f, -6.0f, 0.0f,
			basePosition + baseScale * glm::vec3(-8.006f, 1.89f, -0.384f));
		m_basicMeshes->DrawBoxMesh();

		// E
		SetTransformations(baseScale * glm::vec3(1.13f, 0.7f, 1.13f), 0.0f, -6.0f, 0.0f,
			basePosition + baseScale * glm::vec3(-6.743f, 1.89f, -0.251f));
		m_basicMeshes->DrawBoxMesh();

		// R
		SetTransformations(baseScale * glm::vec3(1.13f, 0.7f, 1.13f), 0.0f, -6.0f, 0.0f,
			basePosition + baseScale * glm::vec3(-5.48f, 1.89f, -0.118f));
		m_basicMeshes->DrawBoxMesh();

		// T
		SetTransformations(baseScale * glm::vec3(1.13f, 0.7f, 1.13f), 0.0f, -6.0f, 0.0f,
			basePosition + baseScale * glm::vec3(-4.217f, 1.89f, 0.014f));
		m_basicMeshes->DrawBoxMesh();

		// A
		SetTransformations(baseScale * glm::vec3(1.13f, 0.7f, 1.13f), 0.0f, -6.0f, 0.0f,
			basePosition + baseScale * glm::vec3(-9.086f, 1.89f, 0.78f));
		m_basicMeshes->DrawBoxMesh();

		// S
		SetTransformations(baseScale * glm::vec3(1.13f, 0.7f, 1.13f), 0.0f, -6.0f, 0.0f,
			basePosition + baseScale * glm::vec3(-7.823f, 1.89f, 0.912f));
		m_basicMeshes->DrawBoxMesh();

		// D
		SetTransformations(baseScale * glm::vec3(1.13f, 0.7f, 1.13f), 0.0f, -6.0f, 0.0f,
			basePosition + baseScale * glm::vec3(-6.56f, 1.89f, 1.045f));
		m_basicMeshes->DrawBoxMesh();

		// F
		SetTransformations(baseScale * glm::vec3(1.13f, 0.7f, 1.13f), 0.0f, -6.0f, 0.0f,
			basePosition + baseScale * glm::vec3(-5.297f, 1.89f, 1.178f));
		m_basicMeshes->DrawBoxMesh();

		// G
		SetTransformations(baseScale * glm::vec3(1.13f, 0.7f, 1.13f), 0.0f, -6.0f, 0.0f,
			basePosition + baseScale * glm::vec3(-4.034f, 1.89f, 1.311f));
		m_basicMeshes->DrawBoxMesh();

		// Z
		SetTransformations(baseScale * glm::vec3(1.13f, 0.7f, 1.13f), 0.0f, -6.0f, 0.0f,
			basePosition + baseScale * glm::vec3(-8.588f, 1.89f, 2.109f));
		m_basicMeshes->DrawBoxMesh();

		// X
		SetTransformations(baseScale * glm::vec3(1.13f, 0.7f, 1.13f), 0.0f, -6.0f, 0.0f,
			basePosition + baseScale * glm::vec3(-7.325f, 1.89f, 2.242f));
		m_basicMeshes->DrawBoxMesh();

		// C
		SetTransformations(baseScale * glm::vec3(1.13f, 0.7f, 1.13f), 0.0f, -6.0f, 0.0f,
			basePosition + baseScale * glm::vec3(-6.062f, 1.89f, 2.375f));
		m_basicMeshes->DrawBoxMesh();

		// V
		SetTransformations(baseScale * glm::vec3(1.13f, 0.7f, 1.13f), 0.0f, -6.0f, 0.0f,
			basePosition + baseScale * glm::vec3(-4.799f, 1.89f, 2.507f));
		m_basicMeshes->DrawBoxMesh();

		// left B
		SetTransformations(baseScale * glm::vec3(1.13f, 0.7f, 1.13f), 0.0f, -6.0f, 0.0f,
			basePosition + baseScale * glm::vec3(-3.536f, 1.89f, 2.64f));
		m_basicMeshes->DrawBoxMesh();

		// 7
		SetTransformations(baseScale * glm::vec3(1.13f, 0.7f, 1.13f), 0.0f, 6.0f, 0.0f,
			basePosition + baseScale * glm::vec3(-1.638f, 1.89f, -1.049f));
		m_basicMeshes->DrawBoxMesh();

		// 8
		SetTransformations(baseScale * glm::vec3(1.13f, 0.7f, 1.13f), 0.0f, 6.0f, 0.0f,
			basePosition + baseScale * glm::vec3(-0.375f, 1.89f, -1.182f));
		m_basicMeshes->DrawBoxMesh();

		// 9
		SetTransformations(baseScale * glm::vec3(1.13f, 0.7f, 1.13f), 0.0f, 6.0f, 0.0f,
			basePosition + baseScale * glm::vec3(0.888f, 1.89f, -1.315f));
		m_basicMeshes->DrawBoxMesh();

		// 0
		SetTransformations(baseScale * glm::vec3(1.13f, 0.7f, 1.13f), 0.0f, 6.0f, 0.0f,
			basePosition + baseScale * glm::vec3(2.151f, 1.89f, -1.448f));
		m_basicMeshes->DrawBoxMesh();

		// -
		SetTransformations(baseScale * glm::vec3(1.13f, 0.7f, 1.13f), 0.0f, 6.0f, 0.0f,
			basePosition + baseScale * glm::vec3(3.414f, 1.89f, -1.58f));
		m_basicMeshes->DrawBoxMesh();

		// =
		SetTransformations(baseScale * glm::vec3(1.13f, 0.7f, 1.13f), 0.0f, 6.0f, 0.0f,
			basePosition + baseScale * glm::vec3(4.677f, 1.89f, -1.713f));
		m_basicMeshes->DrawBoxMesh();

		// Y
		SetTransformations(baseScale * glm::vec3(1.13f, 0.7f, 1.13f), 0.0f, 6.0f, 0.0f,
			basePosition + baseScale * glm::vec3(-2.137f, 1.89f, 0.28f));
		m_basicMeshes->DrawBoxMesh();

		// U
		SetTransformations(baseScale * glm::vec3(1.13f, 0.7f, 1.13f), 0.0f, 6.0f, 0.0f,
			basePosition + baseScale * glm::vec3(-0.874f, 1.89f, 0.147f));
		m_basicMeshes->DrawBoxMesh();

		// I
		SetTransformations(baseScale * glm::vec3(1.13f, 0.7f, 1.13f), 0.0f, 6.0f, 0.0f,
			basePosition + baseScale * glm::vec3(0.389f, 1.89f, 0.014f));
		m_basicMeshes->DrawBoxMesh();

		// O
		SetTransformations(baseScale * glm::vec3(1.13f, 0.7f, 1.13f), 0.0f, 6.0f, 0.0f,
			basePosition + baseScale * glm::vec3(1.652f, 1.89f, -0.118f));
		m_basicMeshes->DrawBoxMesh();

		// P
		SetTransformations(baseScale * glm::vec3(1.13f, 0.7f, 1.13f), 0.0f, 6.0f, 0.0f,
			basePosition + baseScale * glm::vec3(2.915f, 1.89f, -0.251f));
		m_basicMeshes->DrawBoxMesh();

		// [
		SetTransformations(baseScale * glm::vec3(1.13f, 0.7f, 1.13f), 0.0f, 6.0f, 0.0f,
			basePosition + baseScale * glm::vec3(4.178f, 1.89f, -0.384f));
		m_basicMeshes->DrawBoxMesh();

		// ]
		SetTransformations(baseScale * glm::vec3(1.13f, 0.7f, 1.13f), 0.0f, 6.0f, 0.0f,
			basePosition + baseScale * glm::vec3(5.441f, 1.89f, -0.517f));
		m_basicMeshes->DrawBoxMesh();

		// H
		SetTransformations(baseScale * glm::vec3(1.13f, 0.7f, 1.13f), 0.0f, 6.0f, 0.0f,
			basePosition + baseScale * glm::vec3(-1.689f, 1.89f, 1.51f));
		m_basicMeshes->DrawBoxMesh();

		// J
		SetTransformations(baseScale * glm::vec3(1.13f, 0.7f, 1.13f), 0.0f, 6.0f, 0.0f,
			basePosition + baseScale * glm::vec3(-0.426f, 1.89f, 1.377f));
		m_basicMeshes->DrawBoxMesh();

		// K
		SetTransformations(baseScale * glm::vec3(1.13f, 0.7f, 1.13f), 0.0f, 6.0f, 0.0f,
			basePosition + baseScale * glm::vec3(0.837f, 1.89f, 1.244f));
		m_basicMeshes->DrawBoxMesh();

		// L
		SetTransformations(baseScale * glm::vec3(1.13f, 0.7f, 1.13f), 0.0f, 6.0f, 0.0f,
			basePosition + baseScale * glm::vec3(2.1f, 1.89f, 1.112f));
		m_basicMeshes->DrawBoxMesh();

		// ;
		SetTransformations(baseScale * glm::vec3(1.13f, 0.7f, 1.13f), 0.0f, 6.0f, 0.0f,
			basePosition + baseScale * glm::vec3(3.363f, 1.89f, 0.979f));
		m_basicMeshes->DrawBoxMesh();

		// '
		SetTransformations(baseScale * glm::vec3(1.13f, 0.7f, 1.13f), 0.0f, 6.0f, 0.0f,
			basePosition + baseScale * glm::vec3(4.626f, 1.89f, 0.846f));
		m_basicMeshes->DrawBoxMesh();

		// right B
		SetTransformations(baseScale * glm::vec3(1.13f, 0.7f, 1.13f), 0.0f, 6.0f, 0.0f,
			basePosition + baseScale * glm::vec3(-1.745f, 1.89f, 2.793f));
		m_basicMeshes->DrawBoxMesh();

		// N
		SetTransformations(baseScale * glm::vec3(1.13f, 0.7f, 1.13f), 0.0f, 6.0f, 0.0f,
			basePosition + baseScale * glm::vec3(-0.482f, 1.89f, 2.66f));
		m_basicMeshes->DrawBoxMesh();

		// M
		SetTransformations(baseScale * glm::vec3(1.13f, 0.7f, 1.13f), 0.0f, 6.0f, 0.0f,
			basePosition + baseScale * glm::vec3(0.781f, 1.89f, 2.527f));
		m_basicMeshes->DrawBoxMesh();

		// ,
		SetTransformations(baseScale * glm::vec3(1.13f, 0.7f, 1.13f), 0.0f, 6.0f, 0.0f,
			basePosition + baseScale * glm::vec3(2.044f, 1.89f, 2.395f));
		m_basicMeshes->DrawBoxMesh();

		// .
		SetTransformations(baseScale * glm::vec3(1.13f, 0.7f, 1.13f), 0.0f, 6.0f, 0.0f,
			basePosition + baseScale * glm::vec3(3.307f, 1.89f, 2.262f));
		m_basicMeshes->DrawBoxMesh();

		// /
		SetTransformations(baseScale * glm::vec3(1.13f, 0.7f, 1.13f), 0.0f, 6.0f, 0.0f,
			basePosition + baseScale * glm::vec3(4.57f, 1.89f, 2.129f));
		m_basicMeshes->DrawBoxMesh();

		// Up arrow
		SetTransformations(baseScale * glm::vec3(1.13f, 0.7f, 1.13f), 0.0f, 0.0f, 0.0f,
			basePosition + baseScale * glm::vec3(8.849f, 1.89f, 2.39f));
		m_basicMeshes->DrawBoxMesh();

		// Left arrow
		SetTransformations(baseScale * glm::vec3(1.13f, 0.7f, 1.13f), 0.0f, 0.0f, 0.0f,
			basePosition + baseScale * glm::vec3(7.579f, 1.89f, 3.66f));
		m_basicMeshes->DrawBoxMesh();

		// Down arrow
		SetTransformations(baseScale * glm::vec3(1.13f, 0.7f, 1.13f), 0.0f, 0.0f, 0.0f,
			basePosition + baseScale * glm::vec3(8.849f, 1.89f, 3.66f));
		m_basicMeshes->DrawBoxMesh();

		// Right arrow
		SetTransformations(baseScale * glm::vec3(1.13f, 0.7f, 1.13f), 0.0f, 0.0f, 0.0f,
			basePosition + baseScale * glm::vec3(10.119f, 1.89f, 3.66f));
		m_basicMeshes->DrawBoxMesh();

		// numpad shortcut 1
		SetTransformations(baseScale* glm::vec3(1.13f, 0.7f, 1.13f), 0.0f, 0.0f, 0.0f,
			basePosition + baseScale * glm::vec3(10.437f, 1.89f, -2.881f));
		m_basicMeshes->DrawBoxMesh();

		// numpad shortcut 2
		SetTransformations(baseScale* glm::vec3(1.13f, 0.7f, 1.13f), 0.0f, 0.0f, 0.0f,
			basePosition + baseScale * glm::vec3(11.707f, 1.89f, -2.881f));
		m_basicMeshes->DrawBoxMesh();

		// numpad shortcut 3
		SetTransformations(baseScale* glm::vec3(1.13f, 0.7f, 1.13f), 0.0f, 0.0f, 0.0f,
			basePosition + baseScale * glm::vec3(12.976f, 1.89f, -2.881f));
		m_basicMeshes->DrawBoxMesh();

		// numpad shortcut 4
		SetTransformations(baseScale* glm::vec3(1.13f, 0.7f, 1.13f), 0.0f, 0.0f, 0.0f,
			basePosition + baseScale * glm::vec3(14.246f, 1.89f, -2.881f));
		m_basicMeshes->DrawBoxMesh();

		// Num Clear
		SetTransformations(baseScale* glm::vec3(1.13f, 0.7f, 1.13f), 0.0f, 0.0f, 0.0f,
			basePosition + baseScale * glm::vec3(10.437f, 1.89f, -1.42f));
		m_basicMeshes->DrawBoxMesh();

		// numpad /
		SetTransformations(baseScale* glm::vec3(1.13f, 0.7f, 1.13f), 0.0f, 0.0f, 0.0f,
			basePosition + baseScale * glm::vec3(11.707f, 1.89f, -1.42f));
		m_basicMeshes->DrawBoxMesh();

		// numpad *
		SetTransformations(baseScale* glm::vec3(1.13f, 0.7f, 1.13f), 0.0f, 0.0f, 0.0f,
			basePosition + baseScale * glm::vec3(12.976f, 1.89f, -1.42f));
		m_basicMeshes->DrawBoxMesh();

		// numpad -
		SetTransformations(baseScale* glm::vec3(1.13f, 0.7f, 1.13f), 0.0f, 0.0f, 0.0f,
			basePosition + baseScale * glm::vec3(14.246f, 1.89f, -1.42f));
		m_basicMeshes->DrawBoxMesh();

		// numpad + (two rows tall)
		SetTransformations(baseScale* glm::vec3(1.13f, 0.7f, 2.337f), 0.0f, 0.0f, 0.0f,
			basePosition + baseScale * glm::vec3(14.246f, 1.89f, 0.485f));
		m_basicMeshes->DrawBoxMesh();

		// numpad Enter (two rows tall)
		SetTransformations(baseScale* glm::vec3(1.13f, 0.7f, 2.337f), 0.0f, 0.0f, 0.0f,
			basePosition + baseScale * glm::vec3(14.246f, 1.89f, 3.025f));
		m_basicMeshes->DrawBoxMesh();

		// numpad 7
		SetTransformations(baseScale * glm::vec3(1.13f, 0.7f, 1.13f), 0.0f, 0.0f, 0.0f,
			basePosition + baseScale * glm::vec3(10.437f, 1.89f, -0.15f));
		m_basicMeshes->DrawBoxMesh();

		// numpad 8
		SetTransformations(baseScale * glm::vec3(1.13f, 0.7f, 1.13f), 0.0f, 0.0f, 0.0f,
			basePosition + baseScale * glm::vec3(11.707f, 1.89f, -0.15f));
		m_basicMeshes->DrawBoxMesh();

		// numpad 9
		SetTransformations(baseScale * glm::vec3(1.13f, 0.7f, 1.13f), 0.0f, 0.0f, 0.0f,
			basePosition + baseScale * glm::vec3(12.976f, 1.89f, -0.15f));
		m_basicMeshes->DrawBoxMesh();

		// numpad 4
		SetTransformations(baseScale * glm::vec3(1.13f, 0.7f, 1.13f), 0.0f, 0.0f, 0.0f,
			basePosition + baseScale * glm::vec3(10.437f, 1.89f, 1.12f));
		m_basicMeshes->DrawBoxMesh();

		// numpad 5
		SetTransformations(baseScale * glm::vec3(1.13f, 0.7f, 1.13f), 0.0f, 0.0f, 0.0f,
			basePosition + baseScale * glm::vec3(11.707f, 1.89f, 1.12f));
		m_basicMeshes->DrawBoxMesh();

		// numpad 6
		SetTransformations(baseScale * glm::vec3(1.13f, 0.7f, 1.13f), 0.0f, 0.0f, 0.0f,
			basePosition + baseScale * glm::vec3(12.976f, 1.89f, 1.12f));
		m_basicMeshes->DrawBoxMesh();

		// numpad 1
		SetTransformations(baseScale * glm::vec3(1.13f, 0.7f, 1.13f), 0.0f, 0.0f, 0.0f,
			basePosition + baseScale * glm::vec3(10.437f, 1.89f, 2.39f));
		m_basicMeshes->DrawBoxMesh();

		// numpad 2
		SetTransformations(baseScale * glm::vec3(1.13f, 0.7f, 1.13f), 0.0f, 0.0f, 0.0f,
			basePosition + baseScale * glm::vec3(11.707f, 1.89f, 2.39f));
		m_basicMeshes->DrawBoxMesh();

		// numpad 3
		SetTransformations(baseScale * glm::vec3(1.13f, 0.7f, 1.13f), 0.0f, 0.0f, 0.0f,
			basePosition + baseScale * glm::vec3(12.976f, 1.89f, 2.39f));
		m_basicMeshes->DrawBoxMesh();

		// numpad 0
		SetTransformations(baseScale * glm::vec3(1.13f, 0.7f, 1.13f), 0.0f, 0.0f, 0.0f,
			basePosition + baseScale * glm::vec3(11.707f, 1.89f, 3.66f));
		m_basicMeshes->DrawBoxMesh();

		// numpad .
		SetTransformations(baseScale * glm::vec3(1.13f, 0.7f, 1.13f), 0.0f, 0.0f, 0.0f,
			basePosition + baseScale * glm::vec3(12.976f, 1.89f, 3.66f));
		m_basicMeshes->DrawBoxMesh();

		// --- wrist rest: back edge sits against the case, with a V notch for the front edge ---
		SetShaderTexture("plastic");
		SetTextureUVScale(1.0f, 1.0f);
		SetShaderMaterial("siliconeMat");

		// main body
		SetTransformations(baseScale * glm::vec3(31.07f, 1.27f, 5.19f), 0.0f, 0.0f, 0.0f,
			basePosition + baseScale * glm::vec3(0.635f, 0.635f, 8.355f));
		m_basicMeshes->DrawBoxMesh();

		// left strip (back edge left of the notch)
		SetTransformations(baseScale * glm::vec3(7.366f, 1.27f, 0.53f), 0.0f, 0.0f, 0.0f,
			basePosition + baseScale * glm::vec3(-11.217f, 0.635f, 5.495f));
		m_basicMeshes->DrawBoxMesh();

		// right strip (back edge right of the notch)
		SetTransformations(baseScale * glm::vec3(13.544f, 1.27f, 0.53f), 0.0f, 0.0f, 0.0f,
			basePosition + baseScale * glm::vec3(9.398f, 0.635f, 5.495f));
		m_basicMeshes->DrawBoxMesh();

		// notch wedge, left side
		SetTransformations(baseScale * glm::vec3(5.108f, 1.265f, 1.06f), 0.0f, -6.0f, 0.0f,
			basePosition + baseScale * glm::vec3(-5.049f, 0.633f, 6.022f));
		m_basicMeshes->DrawBoxMesh();

		// notch wedge, right side
		SetTransformations(baseScale * glm::vec3(5.108f, 1.265f, 1.06f), 0.0f, 6.0f, 0.0f,
			basePosition + baseScale * glm::vec3(0.141f, 0.633f, 6.022f));
		m_basicMeshes->DrawBoxMesh();
	}

	void RenderCurvedMonitor(glm::vec3 basePosition, float baseScale)
	{
		float panelHeight = 24.0f;
		float panelThickness = 0.8f;
		float panelCenterY = 19.0f;

		// --- black bezel: 24 boxes, each one stepped sideways, curved forward, and turned ---
		SetShaderTexture("plastic");
		SetTextureUVScale(1.0f, 1.0f);
		SetShaderMaterial("plasticMat");

		for (int i = 0; i < 24; i++)
		{
			float offset = i - 11.5f;						// boxes from the middle: -11.5 (far left) to 11.5 (far right)
			float boxX = offset * 2.2f;						// each box is 2.2 units further over
			float boxZ = offset * offset * 0.0242f - 0.4f;	// edges curve toward the viewer
			float boxTurn = offset * -1.26f;				// each box turns 1.26 degrees more to face the center

			SetTransformations(baseScale * glm::vec3(2.27f, panelHeight, panelThickness), 0.0f, boxTurn, 0.0f,
				basePosition + baseScale * glm::vec3(boxX, panelCenterY, boxZ));
			m_basicMeshes->DrawBoxMesh();
		}

		// --- blue screen: same pattern, slightly narrower and just in front of the bezel ---
		SetShaderColor(0.0f, 0.08f, 0.45f, 1.0f);
		SetShaderMaterial("screenMat");

		for (int i = 0; i < 24; i++)
		{
			float offset = i - 11.5f;
			float boxX = offset * 2.16f;
			float boxZ = offset * offset * 0.0233f + 0.03f;
			float boxTurn = offset * -1.24f;

			SetTransformations(baseScale * glm::vec3(2.23f, 22.2f, 0.04f), 0.0f, boxTurn, 0.0f,
				basePosition + baseScale * glm::vec3(boxX, panelCenterY + 0.3f, boxZ));
			m_basicMeshes->DrawBoxMesh();
		}

		// --- black stand ---
		SetShaderTexture("plastic");
		SetShaderMaterial("plasticMat");

		// rear housing behind the middle of the panel
		SetTransformations(baseScale * glm::vec3(18.0f, 13.0f, 2.6f), 0.0f, 0.0f, 0.0f,
			basePosition + baseScale * glm::vec3(0.0f, 17.5f, -2.1f));
		m_basicMeshes->DrawBoxMesh();

		// neck rising from the hub into the housing
		SetTransformations(baseScale * glm::vec3(0.55f, 11.5f, 0.55f), 0.0f, 0.0f, 0.0f,
			basePosition + baseScale * glm::vec3(0.0f, 0.0f, -2.4f));
		m_basicMeshes->DrawCylinderMesh();

		// domed hub (lower half hidden below the mat)
		SetTransformations(baseScale * glm::vec3(1.3f, 0.7f, 1.3f), 0.0f, 0.0f, 0.0f,
			basePosition + baseScale * glm::vec3(0.0f, 0.0f, -2.4f));
		m_basicMeshes->DrawSphereMesh();

		// left leg: stretched sphere angled out to the front-left
		SetTransformations(baseScale * glm::vec3(0.55f, 0.45f, 10.0f), 0.0f, -55.0f, 0.0f,
			basePosition + baseScale * glm::vec3(-8.19f, 0.0f, 3.34f));
		m_basicMeshes->DrawSphereMesh();

		// right leg: stretched sphere angled out to the front-right
		SetTransformations(baseScale * glm::vec3(0.55f, 0.45f, 10.0f), 0.0f, 55.0f, 0.0f,
			basePosition + baseScale * glm::vec3(8.19f, 0.0f, 3.34f));
		m_basicMeshes->DrawSphereMesh();
		
	}

	void RenderSecondaryMonitor(glm::vec3 basePosition, float baseScale)
	{
		// --- black plastic body ---
		SetShaderTexture("plastic");
		SetShaderMaterial("plasticMat");

		// bezel: portrait
		SetTextureUVScale(2.0f, 3.0f);
		SetTransformations(baseScale * glm::vec3(21.3f, 36.0f, 1.0f), 0.0f, 40.0f, 0.0f,
			basePosition + baseScale * glm::vec3(0.0f, 22.0f, 0.0f));
		m_basicMeshes->DrawBoxMesh();

		// rear housing
		SetTextureUVScale(1.0f, 1.0f);
		SetTransformations(baseScale * glm::vec3(14.0f, 24.0f, 2.2f), 0.0f, 40.0f, 0.0f,
			basePosition + baseScale * glm::vec3(-1.028f, 22.0f, -1.226f));
		m_basicMeshes->DrawBoxMesh();

		// neck
		SetTransformations(baseScale * glm::vec3(3.0f, 14.0f, 1.2f), 0.0f, 40.0f, 0.0f,
			basePosition + baseScale * glm::vec3(-2.121f, 7.0f, -2.528f));
		m_basicMeshes->DrawBoxMesh();

		// base plate
		SetTransformations(baseScale * glm::vec3(12.0f, 0.4f, 8.0f), 0.0f, 40.0f, 0.0f,
			basePosition + baseScale * glm::vec3(-1.607f, 0.2f, -1.915f));
		m_basicMeshes->DrawBoxMesh();

		// --- dark glass screen, just in front of the bezel ---
		SetShaderColor(0.04f, 0.05f, 0.07f, 1.0f);
		SetShaderMaterial("glassMat");
		SetTransformations(baseScale * glm::vec3(19.8f, 34.6f, 0.04f), 0.0f, 40.0f, 0.0f,
			basePosition + baseScale * glm::vec3(0.334f, 22.3f, 0.398f));
		m_basicMeshes->DrawBoxMesh();
	}
	
	public:

	// The following methods are for the students to 
	// customize for their own 3D scene
	void PrepareScene();
	void RenderScene();

};